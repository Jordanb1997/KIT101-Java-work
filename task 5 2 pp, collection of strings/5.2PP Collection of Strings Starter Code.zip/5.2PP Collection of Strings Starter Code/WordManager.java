import java.util.Scanner;

/**
 * Word Manager (5.2PP Collection of Strings)
 *
 * @author Your Name Here
 */
public class WordManager {

    /**
     * Adds the word to the next empty space in the array, if there is space.
     * Returns the new size of the array.
     */
    public static int add(String[] words, int count, String word) {
        //TO DO: Complete the implementation of this method
        
        return count;
    }

    /** Displays the words in the collection as a comma separated list. */
    public static void printList(String[] words, int count) {
        //TO DO: Complete the implementation of this method
    }
    
    //TO DO: Add an implementation of averageLength
    
    public static void main(String[] args ) {
        Scanner sc = new Scanner(System.in);
        
        //TO DO: Add necessary variable (and constant) declarations and initialisations
        
        //TO DO: Implement the menu
    }

}

